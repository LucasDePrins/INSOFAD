import { Component, Input, OnInit } from '@angular/core';
import { OrderComponent } from './order/order.component';
import { UserService } from '../../services/user.service';
import { TokenService } from '../../auth/token.service';
import { CustomUser } from '../../models/customuser.model';
import { CustomOrder } from '../../models/customorder.model';
import { OrderDetailsComponent } from './order-details/order-details.component';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-orders',
  standalone: true,
  imports: [OrderComponent, OrderDetailsComponent, CommonModule],
  templateUrl: './orders.component.html',
  styleUrl: './orders.component.scss'
})
export class OrdersComponent implements OnInit {

  @Input() public user: CustomUser;
  selectedOrderId: number = 0;
  public userLoading: boolean = true;

  constructor(private userService: UserService, private tokenService: TokenService) {}

  ngOnInit(): void {
    this.loadUserInfo();
  }

  loadUserInfo(): void {
    this.userService.getUserInfo().subscribe((user: CustomUser) => {
      this.user = user;
      this.userLoading = false;
      this.loadLatestOrder(this.user);
    });
  }

  loadLatestOrder(user: CustomUser): void {
    // Check if 'customOrders' is defined and has at least one element
    if (user.customOrders && user.customOrders.length > 0) {
        this.selectedOrderId = user.customOrders[0].id;
    } else {
        // Handle the scenario where 'customOrders' is empty or undefined
        // For example, set 'selectedOrderId' to null or show a message
        this.selectedOrderId = null;
        console.log('No orders found for this user.');
    }
}


  onOrderClicked(orderId: number): void {
    this.selectedOrderId = orderId;
  }
}
