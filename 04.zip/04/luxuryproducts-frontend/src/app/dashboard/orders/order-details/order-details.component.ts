import { Component, Input, OnChanges, SimpleChanges } from '@angular/core';
import { CustomOrder } from '../../../models/customorder.model';
import { OrderService } from '../../../services/order.service';
import { OrdersComponent } from '../orders.component';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-order-details',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './order-details.component.html',
  styleUrl: './order-details.component.scss'
})
export class OrderDetailsComponent implements OnChanges {
  @Input() orderId: number;
  orderDetails: CustomOrder;

  constructor(private orderService: OrderService) {}

  ngOnChanges(changes: SimpleChanges) {
    if (changes['orderId'] && this.orderId) {
      this.loadOrderDetails();
    }
  }

  private loadOrderDetails() {
    this.orderService.getOrderDetails(this.orderId).subscribe({
      next: (data: CustomOrder) => {
        this.orderDetails = data;
      },
      error: (error) => {
        console.error('Error fetching order details', error);
      }
    });
  }

  getTotalPrice(orderLines): number {
    const total = orderLines.reduce((acc, orderLine) => acc + (orderLine.unit_price * orderLine.quantity), 0);
    return parseFloat(total.toFixed(2));
  }

}
