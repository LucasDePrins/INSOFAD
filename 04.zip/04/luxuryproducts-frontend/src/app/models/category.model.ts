export class Category {
    private id: number;
    private name: string;
}