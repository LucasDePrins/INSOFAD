import { Product } from "./product.model";

export class OrderLine {

    private _name: string;
    private _description: string;
    private _unit_price: number;
    private _quantity: number;
    public get quantity(): number {
        return this._quantity;
    }
    public set quantity(value: number) {
        this._quantity = value;
    }


    constructor(name: string, description: string, unit_price: number, quantity: number) {
        this.name = name;
        this.description = description;
        this.unit_price = unit_price;
        this._quantity = quantity
    }

    public get name(): string {
        return this._name;
    }
    public set name(value: string) {
        this._name = value;
    }
    public get description(): string {
        return this._description;
    }
    public set description(value: string) {
        this._description = value;
    }
    public get unit_price(): number {
        return this._unit_price;
    }
    public set unit_price(value: number) {
        this._unit_price = value;
    }
}
