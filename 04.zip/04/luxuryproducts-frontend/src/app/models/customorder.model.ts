import { CustomUser } from "./customuser.model";
import { OrderLine } from "./orderline.model";

export class CustomOrder {
    private _id: number;
    private _datum: string;
    private _orderStatus: string;
    private _orderLines: OrderLine[];
    private _customUser: CustomUser;

    constructor(id: number, datum: string, orderStatus: string, orderLines: OrderLine[], customUser: CustomUser) {
        this._id = id;
        this._datum = datum;
        this._orderStatus = orderStatus;
        this._orderLines = orderLines;
        this._customUser = customUser;
    }

    public get id(): number {
        return this._id;
    }
    public set id(value: number) {
        this._id = value;
    }
    public get datum(): string {
        return this._datum;
    }
    public set datum(value: string) {
        this._datum = value;
    }
    public get orderStatus(): string {
        return this._orderStatus;
    }
    public set orderStatus(value: string) {
        this._orderStatus = value;
    }
    public get orderLines(): OrderLine[] {
        return this._orderLines;
    }
    public set orderLines(value: OrderLine[]) {
        this._orderLines = value;
    }
    public get customUser(): CustomUser {
        return this._customUser;
    }
    public set customUser(value: CustomUser) {
        this._customUser = value;
    }
    
}