import { Injectable } from '@angular/core';
import { Product } from '../models/product.model';
import { Observable, delay, of } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../environments/environment.development';

@Injectable({
  providedIn: 'root'
})
export class ProductsService {

  constructor(private http: HttpClient) { }

  public getAllProducts(categoryId: number): Observable<Product[]> {
    console.log(categoryId);
    const numericCategoryId = Number(categoryId);

    if (numericCategoryId === 1 || numericCategoryId === 2) {
      return this.http.get<Product[]>(environment.base_url + '/products?category=' + categoryId);
  } else {
      return this.http.get<Product[]>(environment.base_url + '/products');
  }
}

  public getProductById(productId: number): Observable<Product> {
    return this.http.get<Product>(environment.base_url + '/products/' + productId)
  }

}
