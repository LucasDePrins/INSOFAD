import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { TokenService } from '../auth/token.service';
import { CustomOrder } from '../models/customorder.model';
import { Observable, catchError, map, tap, throwError } from 'rxjs';
import { OrderLine } from '../models/orderline.model';
import { Product } from '../models/product.model';
import { CartItem } from '../models/cartitem.model';
import { environment } from '../../environments/environment.development';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class OrderService {

  currentOrder: Observable<CustomOrder>;
  currentOrderId: number = 0;

  requestBodyPostOrderLine: string;


  private orderUrl = environment.base_url + '/orders';
  private orderLineUrl = environment.base_url + '/orderline';

  constructor(private http: HttpClient, private tokenService: TokenService, private router: Router) { }

  public placeOrder(): Observable<string> {
    if (this.tokenService.isValid()) {
      const currentDate = new Date();
    const datum: string = currentDate.toDateString();
    const orderStatus: string = "Processing...";

    const bodyOrder = {
    datum: datum,
    orderStatus: orderStatus
  };

    const requestBodyPostOrder: string = JSON.stringify(bodyOrder);

    const headers = new HttpHeaders({
      'Authorization': 'Bearer ' + this.tokenService.loadToken(),
      'Content-Type': 'application/json'
    });
  
    return this.http.post(this.orderUrl, requestBodyPostOrder, {
      headers: headers,
      responseType: 'text'
    }).pipe(
      tap(response => {
        console.log('Order response:', response);
      }),
      catchError(error => {
        console.error('Error placing order:', error);
        return throwError(() => error);
      })
    );
    } else {
      this.router.navigate(['/auth/login']); // Redirect to login/register
      return new Observable<string>();
    }
  }

  public addOrderLineToOrder(cartItem: CartItem): Observable<string> {
    const headers = new HttpHeaders({
      'Authorization': 'Bearer ' + this.tokenService.loadToken(),
      'Content-Type': 'application/json'
    });
  
    const orderLineBody = {
      name: cartItem.product.name,
      description: cartItem.product.description,
      unit_price: cartItem.product.price,
      quantity: cartItem.quantity,  // Add the quantity field
      order_id: this.currentOrderId
    };
  
    this.requestBodyPostOrderLine = JSON.stringify(orderLineBody);
  
    return this.http.post(this.orderLineUrl, this.requestBodyPostOrderLine, { 
      headers: headers, 
      responseType: 'text' // Expecting a text response from the server
    });
  }
  

  public getOrderDetails(orderId: number): Observable<CustomOrder> {
    const headers = new HttpHeaders({
      'Authorization': 'Bearer ' + this.tokenService.loadToken(),
      'Content-Type': 'application/json'
    });
    return this.http.get<CustomOrder>(`${this.orderUrl}?id=${orderId}`, { headers })
               .pipe(
                 catchError(this.handleError)
               );
}

private handleError(error: any) {
  return throwError(() => new Error('Er is iets misgegaan bij het ophalen van de order. ' + error.message));
}
}  
