import { Component } from '@angular/core';
import { CartService } from '../services/cart.service';
import { Product } from '../models/product.model';
import { OrderService } from '../services/order.service';
import { HttpErrorResponse } from '@angular/common/http';
import { LoginComponent } from '../auth/login/login.component';
import { Observable, catchError, concatMap, findIndex, from, of } from 'rxjs';
import { CustomOrder } from '../models/customorder.model';
import { CartItem } from '../models/cartitem.model';
import { CommonModule } from '@angular/common';
import { NewAddressComponent } from '../new-address/new-address.component';
import { TokenService } from '../auth/token.service';
import { UserService } from '../services/user.service';
import { CustomUser } from '../models/customuser.model';
import { Router } from '@angular/router';

@Component({
  selector: 'app-cart',
  standalone: true,
  imports: [CommonModule, NewAddressComponent],
  templateUrl: './cart.component.html',
  styleUrl: './cart.component.scss'
})
export class CartComponent {
  isLoggedIn$: Observable<Boolean>;
  user: CustomUser;

  ngOnInit() {
    this.cartService.cartUpdated.subscribe(() => {
        this.refreshCart();
    });
    this.isLoggedIn$ = this.tokenService.getIsAuthenticated(); // Assume this method returns an Observable<boolean>
    this.isLoggedIn$.subscribe(isLoggedIn => {
      if (isLoggedIn) {
        this.userService.getUserInfo().subscribe((user: CustomUser) => {
          this.user = user;
        });
      } else {
        this.user = null;
      }
    });
}

refreshCart() {
    this.productsInCart = this.cartService.getAllProductsFromCart();
    this.totalOrderValue = this.cartService.calculateTotalOrderValue();
}

  public productsInCart: CartItem[];
  public totalOrderValue: Number;

  constructor(private cartService: CartService, private orderService: OrderService, private tokenService: TokenService, private userService: UserService, private router: Router) {
    this.productsInCart = this.cartService.getAllProductsFromCart();
    this.totalOrderValue = this.cartService.calculateTotalOrderValue();
    this.orderService = orderService;
  }

  removeFromCart(index: number) {
    this.cartService.removeProductFromCart(index)
  }

  placeOrder(): void {
    this.orderService.placeOrder().subscribe({
      next: (response) => {
        console.log('Order placed successfully', response);
  
        // Assuming response contains the orderId
        this.orderService.currentOrderId = Number(response);
  
        // Add each product in the cart as an order line
        for (const product of this.productsInCart) {
          this.orderService.addOrderLineToOrder(product).subscribe({
            next: (orderLineResponse) => {
              console.log('Order line added successfully', orderLineResponse);
            },
            error: (error) => {
              console.error('Error adding order line', error);
            }
          });
        }
        this.cartService.clearCart()
        this.cartService.navigateToOrder()
      },
      error: (error) => {
        console.error('Error placing order', error);
        this.handleOrderError();
      }
    });
  }
    
  handleOrderError(): void {
      from(this.productsInCart).pipe(
        concatMap(product => 
          this.orderService.addOrderLineToOrder(product).pipe(
            catchError(err => {
              console.error('Error adding product to order', product, err);
              // Return a safe value or rethrow, depending on your needs
              return of(null);
            })
          )
        )
      ).subscribe({
        next: (response) => {
          if (response) {
            console.log('Product added to order', response);
          }
        },
        complete: () => {
          console.log('Processed all products in cart');
        }
      });
  }

  public totalItems(): number {
    return this.productsInCart.reduce((total, cartItem) => total + cartItem.quantity, 0);
  }

  increaseQuantity(index: number) {
    if (this.productsInCart[index]) {
      this.productsInCart[index].quantity += 1;
    }    this.refreshCart();
  }
  
  decreaseQuantity(index: number) {
    if (this.productsInCart[index] && this.productsInCart[index].quantity > 1) {
      this.productsInCart[index].quantity -= 1;
    }    this.refreshCart();
  }

  logIn(): void {
    // Navigate to login page or open login modal
    // For example:
    this.router.navigate(['/auth/login']);
  }
  
}
