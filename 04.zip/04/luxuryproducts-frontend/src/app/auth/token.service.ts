import { Injectable } from '@angular/core';
import { JwtPayload } from './jwt-payload.model';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class TokenService {
  private isAuthenticated = new BehaviorSubject<boolean>(this.hasValidToken());

  constructor() {}

  private hasValidToken(): boolean {
    const token = this.loadToken();
    return token != null && !this.tokenExpired(token);
  }

  public getIsAuthenticated(): Observable<boolean> {
    return this.isAuthenticated.asObservable();
  }

  public storeToken(token: string): void {
    localStorage.setItem('token', token);
    this.isAuthenticated.next(true);
  }

  public loadToken(): string | null {
    return localStorage.getItem('token');
  }

  public dropToken(): void {
    localStorage.removeItem('token');
    this.isAuthenticated.next(false);
  }

  private getPayload(token: string): JwtPayload {
    const jwtPayload = token.split('.')[1];
    return JSON.parse(atob(jwtPayload));
  }

  private tokenExpired(token: string): boolean {
    const expiry = this.getPayload(token).exp;
    return (Math.floor((new Date()).getTime() / 1000)) >= expiry;
  }

  public isValid(): boolean {
    const token = this.loadToken();
    return token != null && !this.tokenExpired(token);
  }
}
