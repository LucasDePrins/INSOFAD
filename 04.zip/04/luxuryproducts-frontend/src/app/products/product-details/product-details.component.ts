import { Component, EventEmitter, Input, Output } from '@angular/core';
import { Product } from '../../models/product.model';
import { ProductsService } from '../../services/products.service';
import { ActivatedRoute, Router } from '@angular/router';
import { CartService } from '../../services/cart.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-product-details',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './product-details.component.html',
  styleUrl: './product-details.component.scss'
})
export class ProductDetailsComponent {
  @Input() product: Product;
  @Output() public addToCart: EventEmitter<Product> = new EventEmitter<Product>;
  notificationVisible: boolean = false;

  constructor(
    private route: ActivatedRoute,
    private productService: ProductsService, // This is your service to fetch product details
    private router: Router,
    private cartService: CartService
  ) {}

  ngOnInit(): void {
    this.route.params.subscribe(params => {
      const productId: number = params['id'];
      console.log(productId);
      this.loadProductDetails(productId);
    });
  }

  loadProductDetails(productId: number): void {
    this.productService.getProductById(productId).subscribe({
      next: product => {
        this.product = product;
      },
      error: error => {
        console.error('Error fetching product details', error);
      }
  });
}

public onBuyProduct(): void {
  this.addToCart.emit(this.product);
  this.notificationVisible = true;
  setTimeout(() => this.notificationVisible = false, 3000);
  this.cartService.addProductToCart(this.product);
}

navigateToCart() {
  this.router.navigate(['/cart'])
}

}