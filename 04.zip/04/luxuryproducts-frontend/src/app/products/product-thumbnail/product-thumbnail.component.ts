import { Component, EventEmitter, Input, Output } from '@angular/core';
import { Product } from '../../models/product.model';
import { Router, RouterLink } from '@angular/router';

@Component({
  selector: 'app-product-thumbnail',
  standalone: true,
  imports: [RouterLink],
  templateUrl: './product-thumbnail.component.html',
  styleUrl: './product-thumbnail.component.scss'
})
export class ProductThumbnailComponent {

  @Input() public product: Product;
  @Output() public addToCart: EventEmitter<Product> = new EventEmitter<Product>;

  constructor(private router: Router) {
  }

  notificationVisible: boolean = false;

  public onBuyProduct(): void {
    this.addToCart.emit(this.product);
    this.notificationVisible = true;
    setTimeout(() => this.notificationVisible = false, 3000);
  }

  navigateToCart() {
    this.router.navigate(['/cart'])
  }

  public onViewDetails(): void {
    this.navigateToProductPage();
  }

  public navigateToProductPage() {
    this.router.navigate(['/product-details', this.product.id]);
  }

}
