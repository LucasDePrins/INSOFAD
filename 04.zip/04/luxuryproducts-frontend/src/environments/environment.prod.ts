export const environment = {
    'base_url': ''
};
