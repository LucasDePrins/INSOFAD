package com.example.powerflex.dto;


//import com.example.powerflex.models.ShoppingCart;

public class CustomOrderDTO {

    public String datum;
    public String orderStatus;

}
