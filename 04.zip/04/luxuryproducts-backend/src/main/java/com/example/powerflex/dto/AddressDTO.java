package com.example.powerflex.dto;

//import com.example.powerflex.models.ShoppingCart;

public class AddressDTO {

    public String street;
    public String city;
    public String state;
    public String postalCode;
    public String country;

}
