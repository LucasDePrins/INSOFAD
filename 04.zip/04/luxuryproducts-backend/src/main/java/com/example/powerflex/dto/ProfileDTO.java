package com.example.powerflex.dto;

public class ProfileDTO {
}
