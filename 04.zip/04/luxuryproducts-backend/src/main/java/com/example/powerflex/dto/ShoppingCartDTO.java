//package com.example.powerflex.dto;
//
//import com.fasterxml.jackson.annotation.JsonAlias;
//
//public class ShoppingCartDTO {
//    @JsonAlias("user_id")
//    public long userId;
//
//}
