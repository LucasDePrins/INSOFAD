package com.example.powerflex.dto;

public class CategoryDTO {

    public String name;

}
