package com.example.powerflex;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PowerflexApplication {

    public static void main(String[] args) {
        SpringApplication.run(PowerflexApplication.class, args);
    }

}
