package com.example.powerflex;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PowerflexApplicationTests {

    @Test
    void contextLoads() {
    }

}
